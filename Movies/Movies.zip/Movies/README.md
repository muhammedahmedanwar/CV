# Flix Movie Website

    How To Create Responsive Movie Website Using HTML CSS And jQuery

# Preview

!["How To Create Responsive Movie Website Using HTML CSS And jQuery"](https://user-images.githubusercontent.com/67447840/115097268-514c7800-9f53-11eb-9cd0-b4a3126a0978.png "How To Create Responsive Movie Website Using HTML CSS And jQuery")

# Video

    https://youtu.be/4vgkZslEl1w

# Description

    We will make Responsive Movie Website Using HTML CSS And jQuery, Owl Carousel

# Resource

    Boxicons: https://boxicons.com/

    Google font: https://fonts.google.com/

    Owl Carousel: https://owlcarousel2.github.io/OwlCarousel2/docs/started-welcome.html
